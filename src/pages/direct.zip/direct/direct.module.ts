// import { NgModule } from '@angular/core';
// import { IonicPageModule } from 'ionic-angular';
// import { DirectPage } from './direct';

// @NgModule({
//   declarations: [
//     DirectPage,
//   ],
//   imports: [
//     IonicPageModule.forChild(DirectPage),
//   ],
// })
// export class DirectPageModule {}
