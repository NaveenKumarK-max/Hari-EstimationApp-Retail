import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AddEstiItemPage } from './add-esti-item';

@NgModule({
  declarations: [
    AddEstiItemPage,
  ],
  imports: [
    IonicPageModule.forChild(AddEstiItemPage),
  ],
})
export class AddEstiItemPageModule {}
