import { Component } from '@angular/core';
import { IonicPage, NavParams,ViewController,LoadingController, Events, ModalController } from 'ionic-angular';
import { CommonProvider } from '../../../providers/common';
import { RetailProvider } from '../../../providers/retail';
import { MasSearchPage } from '../../modal/mas-search/mas-search';

/**
 * Generated class for the CusSearchPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-add-esti-item',
  templateUrl: 'add-esti-item.html',
  providers: [CommonProvider,RetailProvider]

})
export class AddEstiItemPage {

  action:any;
  item_type:any;
  id_branch:any;
  msg:any;
  errorMsg:any;
  stnErrMsg:any;
  metalRate:any;
  tax_details:any;
  stones = [];
  stone_details = [];
  esti = [];
  tagData = {"tag_code":"","is_partial":0,"stone_details":[]};
  // NonTag
  ntData = {"stone_details":[]};
  nonTagStock:any;
  products = [];
  designs = [];
  selectedNTStock = [];
  // Home Bill
  hbData = {"tag_code":"","is_partly_sold" : 0, "stone_details":[]};
  homeBillStock:any;
  purities = [];
  collections = [];
  hbProducts = [];
  hbDesigns = [];
  hbPurities = [];
  // Old metal
  omData = {"stone_details":[]};
  oldMetalCat = [];
  oldMetalTypes = [];
  metalCatTypes = [];
  ret_settings = [];
  //empData = JSON.parse(localStorage.getItem('empDetail'));

  constructor(public events: Events, public load:LoadingController, public retail:RetailProvider, public common:CommonProvider,public viewCtrl: ViewController, public navParams: NavParams, public modal: ModalController) {
    this.item_type = this.navParams.get('type');
    this.ret_settings = this.navParams.get('ret_settings');
    this.id_branch = this.navParams.get('id_branch');
    this.metalRate = this.navParams.get('metal_rates');
    this.tax_details = this.navParams.get('taxGroupItems');
    this.nonTagStock = this.navParams.get('nonTagStock');
    this.products = this.nonTagStock.products;
    this.homeBillStock = this.navParams.get('homeBillStock');
    this.purities = this.navParams.get('purities');
    this.collections = this.navParams.get('collections');
    this.oldMetalCat = this.navParams.get('oldMetalCat');
    this.stones = this.navParams.get('stones'); 
    this.action = this.navParams.get('action'); 
    this.oldMetalTypes = this.navParams.get('oldMetalTypes');
    if(this.item_type == 'tag' && this.action == 'edit'){
      this.tagData = this.navParams.get('esti');
    }
    else if(this.item_type == 'non_tag' && this.action == 'edit'){
      this.ntData = this.navParams.get('esti');
    }
    else if(this.item_type == 'home_bill' && this.action == 'edit'){
      this.hbData = this.navParams.get('esti');
    }
    else if(this.item_type == 'old_metal' && this.action == 'edit'){
      this.omData = this.navParams.get('esti');
    }
  }

  dismiss(){
    this.viewCtrl.dismiss();
  }

  updateItem(submitType){
    let data = [];
    data['submitType'] = submitType;
    if(this.item_type == 'tag'){  // Tag
      if(this.tagData['actual_gross_wt'] < this.tagData['gross_wt']  || this.tagData['actual_net_wt'] < this.tagData['net_wt'] || this.tagData['actual_less_wt'] < this.tagData['less_wt']){
        this.msg = "";
        this.errorMsg = "Invalid Tag weight..";
      }else{
        data['item_data'] = this.tagData;
        this.viewCtrl.dismiss(data);
      }
    }
    else if(this.item_type == 'non_tag'){  // Non Tag
      if(this.ntData['id_nontag_item'] == '' || this.ntData['id_nontag_item'] == null || this.ntData['gross_wt'] <= 0){
        this.msg = "";
        this.errorMsg = "Invalid Non-Tag details..";
      }else{
        data['item_data'] = this.ntData;
        this.viewCtrl.dismiss(data);
      }
    }
    else if(this.item_type == 'home_bill'){  // Home Bill
      if(this.hbData['tag_id'] > 0 || this.hbData['gross_wt'] > 0){
        data['item_data'] = this.hbData;
        this.viewCtrl.dismiss(data);
      }else{
        this.msg = "";
        this.errorMsg = "Invalid Home Bill details..";
      }
    }
    else if(this.item_type == 'old_metal'){  // Old metal
      if(this.omData['amount'] > 0 && this.omData['id_purpose'] > 0 && this.omData['id_category'] > 0){
        data['item_data'] = this.omData;
        this.viewCtrl.dismiss(data);
      }else{
        this.msg = "";
        this.errorMsg = "Invalid Old metal details..";
      }
    }
    // Alert Message Timeout
    setTimeout(()=>{
          this.errorMsg = "";
    },this.common.msgTimeout);
  }

  addItem(submitType){
    let data = [];
    data['submitType'] = submitType;
    if(this.item_type == 'tag'){  // Tag
      if(this.tagData['tag_id'] == '' || this.tagData['tag_id'] == null || this.ntData['gross_wt'] <= 0){
        this.msg = "";
        this.errorMsg = "Invalid Tag details..";
      }else{
        data['item_data'] = this.tagData;
        this.viewCtrl.dismiss(data);
      }
    }
    else if(this.item_type == 'non_tag'){  // Non Tag
      if(this.ntData['id_nontag_item'] == '' || this.ntData['id_nontag_item'] == null || this.ntData['gross_wt'] <= 0){
        this.msg = "";
        this.errorMsg = "Invalid Non-Tag details..";
      }else{
        data['item_data'] = this.ntData;
        this.viewCtrl.dismiss(data);
      }
    }
    else if(this.item_type == 'home_bill'){  // Home Bill
      if(this.hbData['tag_id'] > 0 || this.hbData['gross_wt'] > 0){
        data['item_data'] = this.hbData;
        this.viewCtrl.dismiss(data);
      }else{
        this.msg = "";
        this.errorMsg = "Invalid Home Bill details..";
      }
    }
    else if(this.item_type == 'old_metal'){  // Old metal
      if(this.omData['amount'] > 0 && this.omData['id_purpose'] > 0 && this.omData['id_category'] > 0){
        data['item_data'] = this.omData;
        this.viewCtrl.dismiss(data);
      }else{
        this.msg = "";
        this.errorMsg = "Invalid Old metal details..";
      }
    }
    // Alert Message Timeout
    setTimeout(()=>{
          this.errorMsg = "";
    },this.common.msgTimeout);
  }

  calcStoneDetail(){
    let data = {"stone_wt" : 0, "stone_price" : 0};
    this.stone_details.forEach( i => {
      data['stone_wt']   = data['stone_wt'] + Number(i['stone_wt']); 
      data['stone_price'] = data['stone_price'] + Number(i['stone_price']); 
    }) 
    return data;
  }

  calcSaleValue(){
    if(this.item_type == 'tag'){
      if(parseFloat(this.tagData['gross_wt']) <= parseFloat(this.tagData['actual_gross_wt'])  && parseFloat(this.tagData['net_wt']) <= parseFloat(this.tagData['actual_net_wt']) && parseFloat(this.tagData['less_wt']) >= parseFloat(this.tagData['actual_less_wt'])){
        this.tagData['net_wt']    = this.tagData['gross_wt'] - this.tagData['less_wt'];
        let detail = {itemData : this.tagData, metalRate : this.metalRate, tax_details : this.tax_details, item_type : this.item_type};
        this.tagData = this.retail.calculateSaleValue(detail);
      }else{
        this.errorMsg = "Entered weight greater than tag weight";
        this.tagData['gross_wt']  = this.tagData['actual_gross_wt'] ;
        this.tagData['less_wt']   = this.tagData['actual_less_wt'];
        this.tagData['net_wt']    = this.tagData['actual_net_wt'];
        // Alert Message Timeout
            setTimeout(()=>{
              this.errorMsg = "";
        },this.common.msgTimeout);
      }
    }
    else if(this.item_type == 'non_tag'){
      let stData = this.calcStoneDetail(); 
      this.ntData['stone_wt'] = stData['stone_wt']; 
      this.ntData['stone_price'] = stData['stone_price'];  
      if(parseFloat(this.ntData['gross_wt']) > parseFloat(this.selectedNTStock['gross_wt'])){
        this.ntData['gross_wt'] = this.selectedNTStock['gross_wt'];
      }
      if(parseFloat(this.ntData['less_wt']) > parseFloat(this.selectedNTStock['less_wt'])){
        this.ntData['less_wt'] = this.retail.setAsNumber(this.selectedNTStock['less_wt']);
      }
      if(parseFloat(this.ntData['piece']) > parseFloat(this.selectedNTStock['piece'])){
        this.ntData['piece'] = this.selectedNTStock['piece'];
      }
      this.ntData['net_wt']    = parseFloat(this.ntData['gross_wt']) - this.retail.setAsNumber(this.ntData['less_wt']);
      let detail = {itemData : this.ntData, metalRate : this.metalRate, tax_details : this.tax_details, item_type : this.item_type};
      this.ntData = this.retail.calculateSaleValue(detail);
    }
    else if(this.item_type == 'home_bill'){
      let stData = this.calcStoneDetail(); 
      this.hbData['stone_wt'] = stData['stone_wt']; 
      this.hbData['stone_price'] = stData['stone_price'];  
      if(this.hbData['is_partly_sold'] == 1){
        if(parseFloat(this.hbData['gross_wt']) > parseFloat(this.hbData['stock_gross_wt'])){
          this.hbData['gross_wt'] = this.retail.setAsNumber(this.hbData['stock_gross_wt']); 
        }
        if(parseFloat(this.hbData['less_wt']) > parseFloat(this.hbData['stock_less_wt'])){
          this.hbData['less_wt'] = this.retail.setAsNumber(this.hbData['stock_less_wt']);
        }
      } 
      this.hbData['net_wt'] = parseFloat(this.hbData['gross_wt']) - this.retail.setAsNumber(this.hbData['less_wt']);
      let detail = {itemData : this.hbData, metalRate : this.metalRate, tax_details : this.tax_details, item_type : this.item_type};
      this.hbData = this.retail.calculateSaleValue(detail);
    }
  }

  // Tag Item
  getTagData(tag_code){
    if (tag_code.length > 0) {
      let loader = this.load.create({
        content: 'Please Wait',
        spinner: 'bubbles',
      });
      loader.present();
      var postData = {"searchTxt":tag_code,"searchField":"tag_code","id_branch":this.id_branch};
      this.retail.getTagData(postData).then(data=>{
        if(data.status){
            this.msg = data.msg;
            this.errorMsg = "";
            setTimeout(()=>{
                  this.msg = "";
            },this.common.msgTimeout);
            data.tagData['actual_gross_wt'] = data.tagData['gross_wt'];
            data.tagData['actual_less_wt'] = data.tagData['less_wt'];
            data.tagData['actual_net_wt'] = data.tagData['net_wt'];
            data.tagData['product_name'] = ( data.tagData['parent_prods_name'] != null ? (data.tagData['parent_prods_name']+','+data.tagData['product_name']) : data.tagData['product_name'] );
            let  detail = {itemData : data.tagData, metalRate : this.metalRate, tax_details : this.tax_details, item_type : this.item_type};
            this.tagData = this.retail.calculateSaleValue(detail);
        }else{
          this.tagData = {"tag_code":"","is_partial":0,"stone_details":[]};
          this.msg = "";
          this.errorMsg = data.msg;
          setTimeout(()=>{
                this.errorMsg = "";
          },this.common.msgTimeout);
        }

        loader.dismiss();
      })
    }else{
      console.log(tag_code);
      this.errorMsg = "Enter Tag Code";
      setTimeout(()=>{
        this.errorMsg = "";
      },this.common.msgTimeout);
    }
  }

  partlySale(){
    if(this.tagData['is_partial'] == 0){
      this.tagData['gross_wt']  = this.tagData['actual_gross_wt'] ;
      this.tagData['less_wt']   = this.tagData['actual_less_wt'];
      this.tagData['net_wt']    = this.tagData['actual_net_wt'];
    }
  }
  // ./Tag Item

  // Non Tag
  collectionSelected(id_collection){
    this.products = [];
    this.nonTagStock['products'].forEach(prod => {
        if(prod.id_collection == id_collection){
          this.products.push(prod);
        }
    })
  }

  productSelected(id_product){
    this.designs = [];
    this.nonTagStock['designs'].forEach(design => {
        if(design.pro_id == id_product){
          this.designs.push(design);
        }
    })
  }


  setNTitemData(id_design){
    this.selectedNTStock = [];
    this.ntData = {"stone_details":[]};
    this.nonTagStock['nt_items'].forEach(nt_item => {
        if(nt_item.design == id_design){ 
          this.selectedNTStock['gross_wt'] = nt_item.gross_wt;
          this.selectedNTStock['less_wt'] = nt_item.less_wt;
          this.selectedNTStock['net_wt'] = nt_item.net_wt;
          this.selectedNTStock['piece'] = nt_item.piece;
          nt_item.product_name = (nt_item.parent_prods_name != null? nt_item.parent_prods_name+','+nt_item.product_name : nt_item.product_name);
          this.ntData = nt_item;
          if(parseFloat(nt_item.gross_wt) == 0){
            this.errorMsg = "Requested item is currently Out of Stock!!";
            this.msg = "";
            setTimeout(()=>{
                  this.errorMsg = "";
            },this.common.msgTimeout);
          }
          if(parseFloat(nt_item.gross_wt) > 0){
            this.ntData['gross_wt'] = "";
            this.ntData['less_wt'] = "";
            this.ntData['net_wt'] = "";
            this.ntData['piece'] = 1;
            this.ntData['size'] = '';
            this.ntData['purname'] = '';
          }
          console.log(this.ntData);
        }
    })
  }
  // ./Non Tag

  // Home Bill
  getHomeStockByTag(){
    var tag_code = this.hbData['tag_code'];
    if (tag_code && tag_code.trim() != '' && tag_code.length > 0) {
      let loader = this.load.create({
        content: 'Please Wait',
        spinner: 'bubbles',
      });
      loader.present();
      var postData = {"type":"byTag", "searchTxt":tag_code, "searchField":"tag_code", "id_branch":this.id_branch};
      this.retail.getHomeStock(postData).then(data=>{
        if(data.status){
            this.msg = data.msg;
            this.errorMsg = "";
            setTimeout(()=>{
                  this.msg = "";
            },this.common.msgTimeout);
            data.homeStock['stock_gross_wt'] = data.homeStock['gross_wt'];
            data.homeStock['stock_less_wt'] = data.homeStock['less_wt'];
            data.homeStock['stock_net_wt'] = data.homeStock['net_wt'];
            let  detail = {itemData : data.homeStock, metalRate : this.metalRate, tax_details : this.tax_details, item_type : this.item_type};
            this.hbData = this.retail.calculateSaleValue(detail);
        }else{
          this.hbData = {"tag_code":"","is_partly_sold" : 0,"stone_details":[]};
          this.msg = "";
          this.errorMsg = data.msg;
          setTimeout(()=>{
                this.errorMsg = "";
          },this.common.msgTimeout);
        }
        loader.dismiss();
      })
    }
  }

  hbIsPartlySold(is_partly_sold){
    //alert(is_partly_sold);
  }

  hbProdSelected(){ 
    if(this.hbDesigns.length == 0) {
      let loader = this.load.create({
        content: 'Please Wait',
        spinner: 'bubbles',
      });
      loader.present();
      this.retail.getDesigns({"type":"active", "id_product":this.hbData['pro_id'], "last_id":-1}).then(data=>{
        this.hbDesigns = data;
        loader.dismiss();
      })
    }  
    if(this.hbPurities.length == 0) {
      let loader = this.load.create({
        content: 'Please Wait',
        spinner: 'bubbles',
      });
      loader.present();
      this.retail.getAllPurities(this.hbData['pro_id']).then(data=>{
        this.hbPurities = data;
        loader.dismiss();
      })
    }  
  }

  openMasSearch(master){
    this.errorMsg = "";
    if(master == 'Product'){ 
      let loader = this.load.create({
        content: 'Please Wait',
        spinner: 'bubbles',
      });
      loader.present();
      if(this.ret_settings['subproduct_required'] == 1){
        let filter_by = (this.ret_settings['collections_required'] == 1 ? "collection" : "category" );
        let collection_id = ( this.item_type == "home_bill" ? this.hbData['collection'] : this.ntData['collection'] );
        if(collection_id > 0){
          this.retail.getProductTreeList({"filter_by" : filter_by, "id" : collection_id}).then(data=>{
            if(this.item_type == "home_bill"){
              this.hbProducts = data;
            }
            loader.dismiss();
            this.openMasModal({'searchArr' : data, page : master, listType : "tree"}, master);
          })
        }else{
          loader.dismiss();
          this.errorMsg = "Collection required !!";
          setTimeout(()=>{
            this.errorMsg = "";
          },this.common.msgTimeout);
        }          
      }else{
        if(this.hbProducts.length == 0) {
          this.retail.getProducts({"type":"active", "id_category":"", "last_id":-1}).then(data=>{
            this.hbProducts = data;
            loader.dismiss();
            this.openMasModal({'searchArr' : this.hbProducts, page : master, listType : "normal"}, master);
          })
        }else{
          loader.dismiss();
          this.openMasModal({'searchArr' : this.hbProducts, page : master, listType : "normal"}, master);
        } 
      }       
    }
    else if(master == 'Design'){ 
      if(this.hbData['pro_id']){
         this.openMasModal({'searchArr' : this.hbDesigns, page : master, listType : "normal"}, master);
      }
    } 
    else if(master == 'Purity'){ 
      if(this.hbData['pro_id']){
         this.openMasModal({'searchArr' : this.hbPurities, page : master, listType : "normal"}, master);
      }
    }  
  }

  openMasModal(data,master){ 
    let modal = this.modal.create(MasSearchPage,data)
    modal.present();
    modal.onDidDismiss(data => {
      if(data != null){ 
        if(master == 'Design'){
          this.hbData['design_no'] = data.design_no;
          this.hbData['design_name'] = data.label;
        }
        else if(master == 'Product'){ 
          if(this.item_type == "non_tag"){
            this.ntData['product'] = data.pro_id;
            this.ntData['product_name'] = (data.parent_prods_name != null ? data.parent_prods_name+','+data.label : data.label);
            this.productSelected(data.pro_id);
          }
          else{
            this.hbData['pro_id'] = data.pro_id;
            this.hbData['tax_group_id'] = data.tax_group_id;
            this.hbData['tax_percentage'] = data.tax_percentage;
            this.hbData['calculation_based_on'] = data.calculation_based_on;
            this.hbData['metal_type'] = data.metal_type;
            this.hbData['product_name'] = (data.parent_prods_name != null ? data.parent_prods_name+','+data.label : data.label);
            this.hbProdSelected();
          }          
        }
        else if(master == 'Purity'){
          this.hbData['purity'] = data.id_purity;
          this.hbData['purname'] = data.label;
          this.hbProdSelected();
        }        
      }
    });
  }
  // ./Home Bill

  // Old Metal
  calcOldmetalValue(changedInput){
    this.omData['other_stone_wt'] = 0 ;
    this.omData['other_stone_price'] = 0 ;
    if(changedInput == 'id_category'){
      let cat =  this.oldMetalCat.filter((i: any) => i.id_category == this.omData['id_category']);
      this.omData['category'] = cat[0].cat_name;
      let metaltype =  this.oldMetalTypes.filter((i: any) => i.id_metal == this.omData['id_category']);
      this.metalCatTypes = metaltype;
    }
    else if(changedInput == 'id_purpose'){
      this.omData['purpose'] = ( this.omData['id_purpose'] == 1 ? "Cash": "Exchange" );
    }
    if(changedInput == 'stone')
    {
      let stData = this.calcStoneDetail(); 
      this.omData['other_stone_wt'] = stData['stone_wt']; 
      this.omData['other_stone_price'] = stData['stone_price'];  
    }
    this.omData['stone_details'] = this.stone_details; 
    let gross_wt  = this.retail.setAsNumber(this.omData['gross_wt']);
    let dust_wt   = this.retail.setAsNumber(this.omData['dust_wt']);
    let stone_wt  = this.retail.setAsNumber(this.omData['stone_wt']); 
    let other_stone_wt  = this.retail.setAsNumber(this.omData['other_stone_wt']);
    let other_stone_price = this.retail.setAsNumber(this.omData['other_stone_price']);
    let rate_per_grm   	= this.retail.setAsNumber(this.omData['rate']);
    let wast_wgt   	=  this.retail.setAsNumber(this.omData['wastage_wt']);
    let wast_percent= this.retail.setAsNumber(this.omData['wastage']);
    let net_wt 			= parseFloat(((gross_wt) - (dust_wt) - (stone_wt) - (other_stone_wt) - (wast_wgt)).toFixed(3));
    if(changedInput == 'wastage_wt'){
      let wast_percent= (((wast_wgt)*100)/net_wt);
      this.omData['wastage']  = wast_percent;
    }
    else if(changedInput == 'wastage'){ // wastage %
      let wast_wgt    = parseFloat( (net_wt * (wast_percent / 100)).toFixed(3));
      this.omData['wastage_wt']  = wast_wgt;
    }
    net_wt 			= parseFloat(((gross_wt) - (dust_wt) - (stone_wt) - (other_stone_wt) - (wast_wgt)).toFixed(3));
    let amount 	= parseFloat( ((net_wt*rate_per_grm)+(other_stone_price)).toFixed(2));
    this.omData['net_wt']  = net_wt;
    this.omData['amount']  = amount;
  }

  // ./Old Metal

  // Stone Details
  addStone(){
    let addRow = true;
    this.stone_details.forEach( i => {
      if(i['stone_id'] == ''){
        addRow = false;
      }
    })
    if(addRow){
      this.stone_details.push({"stone_id" : "", "stone_pcs" : "1", "stone_wt" : "0", "st_price" : "0"});
    }
    else{
      setTimeout(()=>{
        this.stnErrMsg = "Invalid stone detail..";
      },this.common.msgTimeout);
    }   
    console.log(this.stone_details) ;
  }

  deleteStone(idx){
    this.stone_details.splice(idx,1);
    this.calcOldmetalValue('stone');
  }
  // ./Stone Details

  /*getCatPurities(id_category){
    let loader = this.load.create({
      content: 'Please Wait',
      spinner: 'bubbles',
    });
    loader.present();
    this.retail.getCatPurities(postData).then(data=>{
      loader.dismiss();
    })
  }*/

  ionViewDidLoad() {

  }

}
