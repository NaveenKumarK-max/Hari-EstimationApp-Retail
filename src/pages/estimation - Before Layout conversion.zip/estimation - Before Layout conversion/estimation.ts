import { Component, Pipe, PipeTransform, trigger, state, style, transition, animate, keyframes, ElementRef ,ViewChild   } from '@angular/core';
import { NavController, Events, LoadingController, ToastController, ModalController   } from 'ionic-angular';
import { DecimalPipe } from '@angular/common';
import { QRScanner, QRScannerStatus } from '@ionic-native/qr-scanner';
import { Printer, PrintOptions } from '@ionic-native/printer';
import { CommonProvider } from '../../providers/common';
import { RetailProvider } from '../../providers/retail';
import { CusSearchPage } from '../modal/customer/customer';
import { AddEstiItemPage } from '../modal/add-esti-item/add-esti-item';
import { EmpSearchPage } from '../modal/employee/employee';
/*
  Generated class for the Estimation page.

  See http://ionicframework.com/docs/v2/components/#navigation for more info on
  Ionic pages and navigation.
*/
@Component({
  selector: 'page-estimation',
  templateUrl: 'estimation.html',
  providers: [CommonProvider, RetailProvider]

})

export class EstiPage {     
  empData = JSON.parse(localStorage.getItem('empDetail'));
  branches = [];
  employees = [];
  askBranch = 0;
  selectedCusData = [];
  nonTagStock:any;
  homeBillStock:any;
  metalRate:any;
  taxGroupItems:any;
  settings = [];
  tagMsg = "";
  tagErrorMsg = "";
  scannerOn = false;
  scanSub:any;
  ntMsg = "";
  ntErrorMsg = "";
  hbMsg = "";
  hbErrorMsg = "";
  purities = [];
  omErrorMsg = "";
  ombMsg = "";
  oldMetalCat = [];
  stones = [];
  esti = {"cus_id": "", "customer" : "", "id_branch" : "", "id_employee" : "","is_tag": false, "is_non_tag": false, "is_home_bill": false, "is_old_metal": false, "tag":[], "non_tag":[], "home_bill":[], "old_metal":[]};
  tot_purch_wgt = 0;
  tot_purch_rate = 0;
  tot_sale_wgt = 0;
  tot_sale_rate = 0;
  total_esti_value = 0; 

  constructor(public load:LoadingController, private qrScanner: QRScanner, private printer : Printer, private nav: NavController, private events: Events, private commonservice: CommonProvider, public retail:RetailProvider, private toast: ToastController, private event: Events, public modal: ModalController, public common: CommonProvider) {
    this.nav = nav;
    let loggedInBranch = this.empData['id_branch'];
    this.esti['id_log'] = this.empData['id_log'];
    if((loggedInBranch == 0 || loggedInBranch == '' || loggedInBranch == null) && this.empData['branch_settings'] == 1){
      this.askBranch = 1;
      this.common.getbranch().then(data=>{
        this.branches = data;
      })
    }else{
      this.esti['id_branch'] = loggedInBranch;
    }
    this.common.getCurrencyAndSettings({"id_branch":this.esti['id_branch']}).then(data=>{
      this.metalRate = data.metal_rates;
      this.settings = data.settings;
    })    
    /*this.retail.getHomeStock({"type":"all", "searchTxt":"", "searchField":"", "id_branch":this.esti['id_branch']}).then(data=>{
      this.homeBillStock = data;
    })*/
  } 

  ionViewDidLoad() {
    let loader = this.load.create({
      content: 'Please Wait',
      spinner: 'dots',
    });
    loader.present();
    this.common.getBranchEmployees(this.empData['id_branch']).then(data=>{
      this.employees = data;
      loader.dismiss();
    })
    this.retail.getAllTaxGroupItems().then(data=>{
      this.taxGroupItems = data;
    })
  }

  /* for footer as hide in default. it's assigned in app.components.ts */
  ionViewWillEnter() {

  }

  selectedEstiType(type,data){
    let loader = this.load.create({
      content: 'Please Wait',
      spinner: 'dots',
    });
    loader.present();
    if(type != 'tag'){
      if(data){
        this.retail.getStones({"id_branch":this.esti['id_branch']}).then(data=>{
          this.stones = data;
          loader.dismiss();
        })
        if(type == 'non_tag'){
          this.retail.getNonTagItems({"id_branch":this.esti['id_branch']}).then(data=>{
            this.nonTagStock = data;
            loader.dismiss();
          }) 
        }
        if(type == 'home_bill'){
          this.retail.getAllPurities("").then(data=>{
            this.purities = data;
            loader.dismiss();
          }) 
        }
      }else{ 
        this.esti[type] = [];
        this.calcEstiSummary();
        loader.dismiss();
      }
    }
    else{
      if(!data){
        this.esti['tag'] = [];
        this.calcEstiSummary();
      }
      loader.dismiss();
    }
  }

  empSelected(){
    let emp = {"allowed_old_met_pur" : ""};
    this.employees.forEach(e => {
      if(this.esti['id_employee'] == e.id_employee){
        emp = e;
      }
    })
    if(emp.allowed_old_met_pur != ''){
      var categories = emp.allowed_old_met_pur;
      var catArr   = categories.split(",");
      catArr.forEach(cat => {
        var categoryArr = cat.split("-");
        this.oldMetalCat.push({"id_category" : categoryArr[0], "cat_name" : categoryArr[1]});
      })
    }
  }

  openCusModal() {
    let modal = this.modal.create(CusSearchPage)
    modal.present();
    modal.onDidDismiss(data => {
      if(data != null){
        this.selectedCusData = data;
        this.esti['cus_id'] = data.id_customer;
        this.esti['customer'] = data.label;
      }
    });
  }

  openEmpModal(){
    let modal = this.modal.create(EmpSearchPage,{"empData" : this.employees})
    modal.present();
    modal.onDidDismiss(data => {
      if(data != null){
        this.esti['id_employee'] = data.id_employee;
        this.esti['emp_name'] = data.emp_name;
        this.empSelected();
      }
    }); 
  }

  openItemAddModal(type) {
    let data = {type:type, id_branch:this.esti['id_branch'], metal_rates:this.metalRate, taxGroupItems:this.taxGroupItems, nonTagStock:this.nonTagStock, homeBillStock : this.homeBillStock, purities : this.purities, oldMetalCat : this.oldMetalCat, stones : this.stones};
    console.log(data);
    let modal = this.modal.create(AddEstiItemPage,data)
    modal.present();
    modal.onDidDismiss(data => {
      if(data != null){
        if(data.item_data != null){
          let addItem = true;
          if(type == "tag"){ // Tag Item
            this.esti[type].forEach(item => {
                if(item.tag_id == data.tag_id){
                  addItem = false;
                  this.tagMsg = "";
                  this.tagErrorMsg = "Tag Already exist..";
                  setTimeout(()=>{
                        this.tagErrorMsg = "";
                  },this.common.msgTimeout);
                }
            })
          }
          if(addItem){
            this.esti[type].push(data.item_data);
          }
        }
        this.calcEstiSummary();
        if(data.item_type == 'SN'){ // Save and New
          this.openItemAddModal(type);
        }
      }
    });
  }

  calcEstiSummary(){
    console.log(this.esti);
    this.tot_sale_wgt = 0;
    this.tot_sale_rate = 0;
    this.tot_purch_wgt = 0;
    this.tot_purch_rate = 0;
    this.esti['tag'].forEach(tag => {
      this.tot_sale_wgt = Number(this.tot_sale_wgt) + Number(tag.net_wt);
      this.tot_sale_rate = Number(this.tot_sale_rate) + Number(tag.sales_value);
    })
    this.esti['non_tag'].forEach(non_tag => {
      this.tot_sale_wgt = Number(this.tot_sale_wgt) + Number(non_tag.net_wt);
      this.tot_sale_rate = Number(this.tot_sale_rate) + Number(non_tag.sales_value);
    })
    this.esti['home_bill'].forEach(home_bill => {
      this.tot_sale_wgt = Number(this.tot_sale_wgt) + Number(home_bill.net_wt);
      this.tot_sale_rate = Number(this.tot_sale_rate) + Number(home_bill.sales_value);
    })
    this.esti['old_metal'].forEach(old_metal => {
      this.tot_purch_wgt = Number(this.tot_purch_wgt) + Number(old_metal.net_wt);
      this.tot_purch_rate = Number(this.tot_purch_rate) + Number(old_metal.amount);
    })
    this.total_esti_value = Number(this.tot_sale_rate) - Number(this.tot_purch_rate);
  }

  closeScanner(){
    this.scannerOn = false;
    this.scanSub.unsubscribe();
    this.qrScanner.hide().then();
    
  }

  /*test(){
    this.scannerOn = !this.scannerOn; 
    const el = document.querySelector('button');
    el.style.setProperty('--display', 'none');
  }*/

  openQRScanner(){
    // Optionally request the permission early
    this.qrScanner.prepare()
    .then((status: QRScannerStatus) => {
      if (status.authorized) {
        // start scanning
        this.scannerOn = true;
        this.scanSub = this.qrScanner.scan().subscribe((text: string) => {
          console.log('Scanned something', text); 
          this.qrScanner.hide().then();
          // Hide and unsubscribe from scanner
          this.scannerOn = false;
          if(text != ''){
            this.getTagByID(text);
          }
          this.scanSub.unsubscribe();
        }); 
        this.qrScanner.show().then();  
      } 
      else if (status.denied) {
        // camera permission was permanently denied
        // you must use QRScanner.openSettings() method to guide the user to the settings page
        // then they can grant the permission from there
        this.qrScanner.openSettings();
      } 
      else {
        // permission was denied, but not permanently. You can ask for permission again at a later time.
        alert('Camera Access permission denied. Kindly enable to Scan QR.');
      }
    })
    .catch((e: any) => console.log('Error is', e));
  }

  getTagByID(tagData){
    if(tagData != ''){
     var istagId = (tagData.search("/") > 0 ? true : false);
     var isTagCode = (tagData.search("-") > 0 ? true : false);
     if(istagId){
       var tId   = tagData.split("/");
       var searchTxt = (tId.length >= 2 ? tId[0] : "");
       var searchField  = "tag_id";
     }
     else if(isTagCode){
       var searchTxt = tagData;
       var searchField  = "tag_code";
     }
     // Search Tag
     let loader = this.load.create({
       content: 'Please Wait',
       spinner: 'dots',
     });
     loader.present();
     var postData = {"searchTxt":searchTxt,"searchField":searchField,"id_branch":this.esti['id_branch']};
     this.retail.getTagData(postData).then(data=>{
       if(data.status){
           this.tagMsg = data.msg;
           this.tagErrorMsg = "";
           setTimeout(()=>{
                 this.tagMsg = "";
           },this.common.msgTimeout);
           data.tagData['actual_gross_wt'] = data.tagData['gross_wt'];
           data.tagData['actual_less_wt'] = data.tagData['less_wt'];
           data.tagData['actual_net_wt'] = data.tagData['net_wt'];
           let detail = {itemData : data.tagData, metalRate : this.metalRate, tax_details : this.taxGroupItems, item_type : "tag"};
           let tagItem = this.retail.calculateSaleValue(detail);
           this.esti['tag'].forEach(item => {
               if(item.tag_id == tagItem.tag_id){
                 this.tagMsg = "";
                 this.tagErrorMsg = "Tag Already exist..";
                 setTimeout(()=>{
                       this.tagErrorMsg = "";
                 },this.common.msgTimeout);
               }
           })
           this.esti['tag'].push(tagItem);
       }else{
         this.tagMsg = "";
         this.tagErrorMsg = data.msg;
         setTimeout(()=>{
               this.tagErrorMsg = "";
         },this.common.msgTimeout);
       }

       loader.dismiss();
     })
    }
  }
  
  deleteItem(item_type, idx){
    if(item_type == 'tag'){
      this.esti[item_type].splice(idx, 1);
      this.tagErrorMsg = "";
      this.tagMsg = "Tag removed from estimation..";
      setTimeout(()=>{
            this.tagMsg = "";
      },this.common.msgTimeout);
    }
    if(item_type == 'non_tag'){
      this.esti[item_type].splice(idx, 1);
      this.ntErrorMsg = "";
      this.ntMsg = "Non-Tag item removed from estimation..";
      setTimeout(()=>{
            this.ntMsg = "";
      },this.common.msgTimeout);
    }
    if(item_type == 'home_bill'){
      this.esti[item_type].splice(idx, 1);
      this.hbErrorMsg = "";
      this.hbMsg = "Home Bill item removed from estimation..";
      setTimeout(()=>{
            this.hbMsg = "";
      },this.common.msgTimeout);
    }
    if(item_type == 'old_metal'){
      this.esti[item_type].splice(idx, 1);
      this.omErrorMsg = "";
      this.ombMsg = "Old Metal item removed from estimation..";
      setTimeout(()=>{
            this.ombMsg = "";
      },this.common.msgTimeout);
    }
  }

  createEsti(){
    console.log(this.esti);
    // Validate Postdata
    if(this.esti['cus_id'] == '' || this.esti['id_employee'] == '' || this.esti['id_branch'] == ''){
      let toastMsg = this.toast.create({
        message: "Please fill required fields",
        duration: this.common.toastTimeout,
        position: 'center'
      });
      toastMsg.present();
    }
    else if(this.esti['is_tag']  || this.esti['is_non_tag'] || this.esti['is_home_bill'] || this.esti['is_old_metal']){
      if(this.esti['tag'] || this.esti['non_tag'] || this.esti['home_bill'] || this.esti['old_metal']){
        let loader = this.load.create({
          content: 'Please Wait',
          spinner: 'dots',
        });
        loader.present();
        this.esti['type'] = 1;
        this.esti['total_cost'] = this.total_esti_value; 
        this.retail.createEstimation(this.esti).then(data=>{
          if(data.status){
            this.tot_sale_wgt = 0;
            this.tot_sale_rate = 0;
            this.tot_purch_wgt = 0;
            this.tot_purch_rate = 0;
            this.total_esti_value = 0;
            this.selectedCusData = [];
            this.esti = {"cus_id" : this.esti['cus_id'], "customer" : this.esti['customer'],"id_branch" : this.esti['id_branch'], "id_employee" : this.esti['id_employee'], "is_tag": false, "is_non_tag": false, "is_home_bill": false, "is_old_metal": false, "tag":[], "non_tag":[], "home_bill":[], "old_metal":[]};
            if(data.cus_copy != ''){
              this.printEsti(data.cus_copy);
            }
          }
          loader.dismiss();
          let toastMsg = this.toast.create({
            message: data.msg,
            duration: this.common.toastTimeout,
            position: 'center'
          });
          toastMsg.present(); 
        })
      }
      else{  
        let toastMsg = this.toast.create({
          message: "Minimum 1 estimation item is required",
          duration: this.common.toastTimeout,
          position: 'center'
        });
        toastMsg.present();
      }
    }
    else{
      let toastMsg = this.toast.create({
        message: "Invalid Estimation",
        duration: this.common.toastTimeout,
        position: 'center'
      });
      toastMsg.present();
    }

  }

  printEsti(content){
    this.printer.isAvailable().then(onSuccess =>{
      console.log("isAvailable - Success");
    }, 
    onError => {
      console.log(onError);
      console.log("isAvailable - Error");
    });

    let options: PrintOptions = {
        name: 'Estimation',
        //printerId: 'printer007',
        //duplex: true,
        //landscape: true,
        grayscale: true
      };
    
    this.printer.print(content, options).then(onSuccess =>{
      console.log("print - Success");
    }, 
    onError => {
      console.log("print - Error");
    });
     
  }

}
